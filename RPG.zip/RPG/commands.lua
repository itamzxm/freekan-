require 'commands.misc'
require 'commands.jail'
require 'commands.where'
