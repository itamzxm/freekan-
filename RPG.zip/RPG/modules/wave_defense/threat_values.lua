local t = {
	["biter-spawner"] = 128,
	["spitter-spawner"] = 128,
	["behemoth-biter"] = 64,
	["behemoth-spitter"] = 64,
	["big-biter"] = 16,
	["big-spitter"] = 16,
	["medium-biter"] = 4,
	["medium-spitter"] = 4,
	["small-biter"] = 1,
	["small-spitter"] = 1,
	["small-worm-turret"] = 16,
	["medium-worm-turret"] = 32,
	["big-worm-turret"] = 64,
	["behemoth-worm-turret"] = 128,
}
return t